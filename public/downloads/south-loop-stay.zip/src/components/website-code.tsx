import Link from "next/link"

import { websiteCodePacks } from "@/data/website-code"
import { Button } from "@/components/ui/button"

export function WebsiteCode() {
  return (
    <section className="border-b border-white/10 bg-[#100e0c]">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-16">
        <p className="text-xs uppercase tracking-[0.22em] text-[#e2b657]">
          Source
        </p>
        <h1 className="mt-2 font-heading text-4xl sm:text-5xl">
          Code: MVP Media Portraits
        </h1>
        <p className="mt-4 max-w-2xl text-lg leading-8 text-[#c9b8a0]">
          Download <code className="text-[#f4ede1]">mvp-media-portraits.zip</code> for
          the headshots site (no age gate). South Loop Stay is running in this
          environment at <code className="text-[#f4ede1]">/desk</code> and also
          mounts portraits at <code className="text-[#f4ede1]">/photo</code>.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          {websiteCodePacks.map((pack) => (
            <Button
              key={pack.id}
              nativeButton={false}
              render={<a href={pack.zipHref} download={pack.zipName} />}
            >
              Download {pack.zipName}
            </Button>
          ))}
        </div>
        <div className="mt-10 grid gap-4 lg:grid-cols-3">
          {websiteCodePacks.map((pack) => (
            <article
              key={pack.id}
              className="flex flex-col rounded-3xl bg-[#1c1814] p-6 ring-1 ring-white/10"
            >
              <p className="text-xs uppercase tracking-[0.18em] text-[#c4a574]">
                {pack.tag} · {pack.folder}
              </p>
              <h2 className="mt-3 font-heading text-2xl">{pack.name}</h2>
              <p className="mt-3 leading-7 text-[#c9b8a0]">{pack.blurb}</p>
              <p className="mt-4 font-mono text-xs leading-5 text-[#e8dcc8]">
                {pack.run}
              </p>
              <ul className="mt-4 flex flex-wrap gap-2 text-sm">
                {pack.pages.map((page) => (
                  <li key={page.href}>
                    <Link className="underline" href={page.href}>
                      {page.label}
                    </Link>
                  </li>
                ))}
              </ul>
              <pre className="mt-4 overflow-x-auto rounded-2xl bg-black/40 p-4 font-mono text-[11px] leading-5 text-[#c9b8a0]">
                {pack.tree.join("\n")}
              </pre>
              <div className="mt-6 flex flex-wrap gap-2">
                <Button
                  nativeButton={false}
                  render={
                    <a href={pack.zipHref} download={pack.zipName} />
                  }
                >
                  Download zip
                </Button>
                <Button
                  nativeButton={false}
                  variant="outline"
                  className="border-white/20 bg-transparent"
                  render={<Link href={pack.previewHref} />}
                >
                  Open site
                </Button>
              </div>
              <p className="mt-3 break-all text-xs text-[#c4a574]">
                GitHub: {pack.github}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
